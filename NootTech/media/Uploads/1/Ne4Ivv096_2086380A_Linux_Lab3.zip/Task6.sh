#!/bin/bash

# Task 6
# Linux Lab 3 - Physics 2T
# Author: 2086380A

# Count the number of .data files in the current directory
data_files_num=`ls -1 *.data 2>/dev/null | wc -l`

# If there are more than 0 .data files...
if [ $data_files_num != 0 ]; then

	# Iterate through all files in current directory ending with .data
	for file in ./*.data; do
		# If file.data.bak does not exist then...
		if [ ! -f "$file.bak" ]; then
			# Use cat to read the contents of file.data
	        	# then redirect it to file.data.bak
			cat $file > "$file.bak"
			echo "- File: $file is not backed up!"
			echo "- Backed up contents to: $file.bak"
		else
			# Else, notify user that file is already backed up
			echo "- File: $file is already backed up! :)"
		fi
		echo " "
	done
else
	echo "There are no .data files in the current directory."
fi
