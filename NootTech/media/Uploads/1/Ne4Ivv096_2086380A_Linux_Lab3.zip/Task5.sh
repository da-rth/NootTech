#!/bin/bash

# Task 5
# Linux Lab 3 - Physics 2T
# Author: 2086380A

# Check if the user has not entered any parameters when executing script
if [ $# -eq 0 ]; then
  echo "You must add a file/directory paths as parameters when running this script!"
  echo "For example: ./Task5.sh /path/to/something /path/to/something_else"
  exit 0
fi

# Iterate through all parameters passed into script
for var in "$@";
do
    # If var is a file...
    if [ -f $var ]; then
	    echo "- '$var' is a file!"
    # If var is a dir...
    elif [ -d $var ]; then
	    echo "- '$var' is a directory!"
    else
	    echo "- '$var' does not exist!"
    fi
done
