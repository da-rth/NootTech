#!/bin/bash

# Task 2
# Linux Lab 3 - Physics 2T
# Author: 2086380A

# Using -p parameter for mdir to create parent directories if they do not already exist 
dirs=("./docs/", "./data/", "./data/processed/")

# Loop through directories
for DIR in ${dirs[@]}; do
    if [ -d "$DIR" ]; then
        # if dir, exit with code 1...
        echo "ERROR: Directory $DIR exists."
        exit 1
    else
        # else, continue to create dir
        echo "SUCCESS: Created directory $DIR!"
        mkdir -p $DIR
    fi
done
