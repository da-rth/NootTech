#!/bin/bash

# Task 7
# Linux Lab 3 - Physics 2T
# Author: 2086380A


# Set directory name (datetime str format) to variable file_dir
file_dir=$(date +%s)


# If file_dir does not already exist...
if [ ! -d $file_dir ]; then
	
	echo "Creating directory $file_dir..."

	# Use mkdir to create the directory
	mkdir $file_dir;
	
	# Loop from 1 to 10, creating 10 random*.dat files
	for i in {1..10};
	do
		# Loop from 1 to 50, appending 50 random nums to file
		for j in {1..50}
		do
			echo $RANDOM >> "./$file_dir/random$i.dat"
		done
		echo "- Created random$i.dat"
	done


else
	echo "The directory $file_dir already exists!"
fi
