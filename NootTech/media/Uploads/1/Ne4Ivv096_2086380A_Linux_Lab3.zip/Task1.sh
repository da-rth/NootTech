#!/bin/bash

# Task 3
# Linux Lab 3 - Physics 2T
# Author: 2086380A

# Using -p parameter for mdir to create parent directories if they do not already exist
mkdir -p "$(pwd)/data/processed"
mkdir -p "$(pwd)/docs"
echo "Directories /data/, /data/processed/ and /docs/ created!"
