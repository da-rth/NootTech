#!/bin/bash

# Task 3
# Linux Lab 3 - Physics 2T
# Author: 2086380A

# num assigned to number of directories in current working directory using pwd and find dir (-type d)
# The output is counted using wc -l
num=`find $(pwd) -mindepth 1 -type d | wc -l`

if [ $num  == 0 ]; then
        echo "$(pwd) has no sub-directories and is at the end of its branch!"
else
        echo "$(pwd) has $num sub-directories!"                              
fi
