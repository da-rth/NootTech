#!/bin/bash

# Task 4
# Linux Lab 3 - Physics 2T
# Author: 2086380A


# Create random file
touch random
echo "'random' file created... appending 100 random numbers!"
# Loop from 1 -> 100
for i in {1..100};
do
	# Echo random num and redirect (append) to 'random' file
	echo $RANDOM >> random
done
echo "done!"
